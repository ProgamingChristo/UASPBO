package com.example.inventoryapp.transaksi

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.ApiConfig
import com.example.inventoryapp.R
import com.example.inventoryapp.produk.Produk
import com.example.inventoryapp.produk.SharedPreferencesHelper
import com.example.inventoryapp.respons.ProsesActivity
import org.json.JSONObject
import org.json.JSONArray
import java.text.NumberFormat
import java.util.Locale

class TransaksiActivity : AppCompatActivity() {

    private lateinit var tvNamaPelanggan: TextView
    private lateinit var tvAlamat: TextView
    private lateinit var tvNomorTelepon: TextView
    private lateinit var tvTanggal: TextView
    private lateinit var tvTotalHarga: TextView
    private lateinit var listViewProduk: ListView
    private lateinit var btnBayar: Button

    private var userId: Int = 0
    private var cartList = mutableListOf<Produk>()
    private var pelangganID: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.transaksi)

        // Inisialisasi view
        tvNamaPelanggan = findViewById(R.id.tvNamaPelanggan)
        tvAlamat = findViewById(R.id.tvAlamat)
        tvNomorTelepon = findViewById(R.id.tvNomorTelepon)
        tvTanggal = findViewById(R.id.tvTanggal)
        tvTotalHarga = findViewById(R.id.tvTotalHarga)
        listViewProduk = findViewById(R.id.listViewProduk)
        btnBayar = findViewById(R.id.btnBayar)

        // Ambil user_id dari SharedPreferences
        userId = getUserIdFromPreferences()

        // Ambil cart list dari SharedPreferences
        cartList = SharedPreferencesHelper.getCartList(this).toMutableList()

        // Set tanggal transaksi
        tvTanggal.text = "Tanggal: ${getCurrentDate()}"

        // Hitung total harga
        val totalHarga = cartList.sumByDouble { it.Harga * it.Quantity }
        tvTotalHarga.text = "Total Harga: ${formatRupiah(totalHarga)}"

        val transaksiAdapter = TransaksiAdapter(this, cartList)
        listViewProduk.adapter = transaksiAdapter

        // Ambil data pelanggan berdasarkan user_id
        fetchPelangganData()

        // Tombol bayar
        btnBayar.setOnClickListener {
            processPayment(totalHarga)
        }
    }

    // Fungsi untuk mengambil user_id dari SharedPreferences
    private fun getUserIdFromPreferences(): Int {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        return sharedPreferences.getInt("user_id", 0)  // Ambil user_id dari SharedPreferences
    }

    // Fungsi untuk mendapatkan tanggal saat ini
    private fun getCurrentDate(): String {
        val format = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return format.format(System.currentTimeMillis())  // Ambil tanggal sekarang
    }

    // Fungsi untuk memformat harga dalam Rupiah
    private fun formatRupiah(amount: Double): String {
        val localeID = Locale("in", "ID")
        val format = NumberFormat.getCurrencyInstance(localeID)
        return format.format(amount)  // Format harga dalam format Rupiah
    }

    // Fungsi untuk mengambil data pelanggan
    private fun fetchPelangganData() {
        val url = ApiConfig.GETPELANGGAN + "$userId"
        val request = StringRequest(Request.Method.GET, url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val pelanggan = jsonResponse.getJSONObject("pelanggan")
                    pelangganID = pelanggan.getInt("PelangganID")

                    // Set data pelanggan
                    tvNamaPelanggan.text = "Nama: ${pelanggan.getString("NamaPelanggan")}"
                    tvAlamat.text = "Alamat: ${pelanggan.getString("Alamat")}"
                    tvNomorTelepon.text = "Nomor Telepon: ${pelanggan.getString("NomorTelepon")}"
                } catch (e: Exception) {
                    Toast.makeText(this, "Error fetching pelanggan data", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    private fun processPayment(totalHarga: Double) {
        if (pelangganID == null) {
            Toast.makeText(this, "Pelanggan ID tidak valid. Pastikan Anda sudah login", Toast.LENGTH_SHORT).show()
            return
        }

        // Buat objek JSON untuk data yang akan dikirim
        val jsonParams = JSONObject().apply {
            val currentDateTime = getCurrentDateTime()  // Ambil waktu dan tanggal saat ini
            put("TanggalPenjualan", currentDateTime)  // Set tanggal transaksi
            put("TotalHarga", totalHarga)  // Total harga transaksi
            put("pelangganID", pelangganID)  // ID pelanggan

            // Buat detailPembelian sebagai array JSON, bukan string
            val detailPembelian = JSONArray().apply {
                cartList.forEach { produk ->
                    put(JSONObject().apply {
                        put("ProdukID", produk.ProdukID)  // ID produk
                        put("JumlahProduk", produk.Quantity)  // Jumlah produk yang dibeli
                        put("Subtotal", produk.Harga * produk.Quantity)  // Subtotal produk
                    })
                }
            }
            put("detailPembelian", detailPembelian)  // Detail pembelian produk
        }

        // Log data yang akan dikirim
        Log.d("ProcessPayment", "Request Data: $jsonParams")

        val url = ApiConfig.POSTPEMBELIAN

        // Membuat request POST untuk mengirim data transaksi ke server
        val request = object : StringRequest(Request.Method.POST, url,
            { response ->
                Toast.makeText(this, "Transaksi berhasil", Toast.LENGTH_SHORT).show()
                // Clear cart setelah transaksi
                SharedPreferencesHelper.saveCartList(this, mutableListOf())

                // Setelah transaksi berhasil, ambil pembelianID dan arahkan ke proses
                val jsonResponse = JSONObject(response)
                val pembelianID = jsonResponse.getInt("pembelianID")

                // Clear cart setelah transaksi berhasil
                clearCart()

                // Simpan pembelianID ke SharedPreferences
                val sharedPreferences = getSharedPreferences("TransactionPrefs", MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                editor.putInt("pembelianID", pembelianID)
                editor.apply()
                finish()

                val intent = Intent(this, ProsesActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)

            },
            { error ->
                Log.e("ProcessPayment", "Error: ${error.message}")
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }) {

            override fun getBody(): ByteArray {
                // Log data JSON yang akan dikirim
                Log.d("ProcessPayment", "Request Body: ${jsonParams.toString()}")
                return jsonParams.toString().toByteArray(Charsets.UTF_8)  // Mengirim data JSON ke server
            }

            override fun getHeaders(): MutableMap<String, String> {
                val headers = mutableMapOf<String, String>()
                headers["Content-Type"] = "application/json"  // Set header content-type sebagai application/json
                return headers
            }
        }

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)  // Menambahkan request ke queue untuk diproses
    }



    // Fungsi untuk mendapatkan tanggal dan waktu saat ini dengan format yang benar
    private fun getCurrentDateTime(): String {
        val format = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
        return format.format(System.currentTimeMillis())  // Mengambil tanggal dan waktu saat ini
    }

    private fun clearCart() {
        cartList.clear()
        SharedPreferencesHelper.saveCartList(this, mutableListOf())
//        Toast.makeText(this, "Cart telah dibersihkan", Toast.LENGTH_SHORT).show()
    }

}
