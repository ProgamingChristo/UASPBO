package com.example.inventoryapp.cart

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.R
import com.example.inventoryapp.produk.Produk
import com.example.inventoryapp.produk.SharedPreferencesHelper
import com.example.inventoryapp.profile.ProfileActivity
import com.example.inventoryapp.transaksi.TransaksiActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.inventoryapp.ApiConfig
import com.example.inventoryapp.produk.ProdukActivity
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class CartActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var cartAdapter: CartAdapter
    private val cartList = mutableListOf<Produk>()
    private lateinit var btnCheckout: Button  // Tombol checkout
    private var userId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cart)

        // Ambil user_id dari SharedPreferences
        userId = getUserIdFromPreferences()

        listView = findViewById(R.id.listView)
        btnCheckout = findViewById(R.id.btnCheckout)  // Inisialisasi tombol checkout
        cartAdapter = CartAdapter(this, cartList)
        listView.adapter = cartAdapter

        // Ambil cartList dari SharedPreferences
        val storedCartList = SharedPreferencesHelper.getCartList(this)
        cartList.addAll(storedCartList)

        // Format harga dalam Rupiah untuk setiap produk di keranjang
        for (produk in cartList) {
            produk.HargaFormatted = formatRupiah(produk.Harga)
        }

        cartAdapter.notifyDataSetChanged()

        // Bottom navigation setup
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomnav)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    startActivity(Intent(this, ProdukActivity::class.java))
                    true
                }
                R.id.navigation_cart -> {
                    startActivity(Intent(this, CartActivity::class.java))
                    true
                }
                R.id.navigation_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // Tombol checkout, mengarah ke halaman TransaksiActivity
        btnCheckout.setOnClickListener {
            if (cartList.isNotEmpty()) {
                // Cek data pelanggan terlebih dahulu sebelum checkout
                checkCustomerData { isDataAvailable ->
                    if (isDataAvailable) {
                        startActivity(Intent(this, TransaksiActivity::class.java))
                    } else {
                        // Jika data pelanggan tidak ditemukan, beri tahu pengguna dan arahkan ke ProfileActivity
                        SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
                            .setTitleText("Data belum lengkap")
                            .setContentText("Anda belum mengisi informasi pelanggan. Klik OK untuk mengisi data.")
                            .setConfirmText("OK")
                            .setConfirmClickListener {
                                startActivity(Intent(this, ProfileActivity::class.java))
                                it.dismissWithAnimation()
                            }
                            .show()
                    }
                }
            } else {
                Toast.makeText(this, "Keranjang kosong, tidak bisa checkout", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        // Simpan cartList yang sudah diperbarui
        SharedPreferencesHelper.saveCartList(this, cartList)
    }

    // Fungsi untuk memformat harga dalam Rupiah
    private fun formatRupiah(amount: Double): String {
        val localeID = Locale("in", "ID")
        val format = NumberFormat.getCurrencyInstance(localeID)
        return format.format(amount)
    }

    // Fungsi untuk mengambil user_id dari SharedPreferences
    private fun getUserIdFromPreferences(): Int {
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        return sharedPreferences.getInt("user_id", 0)  // Ambil user_id dari SharedPreferences
    }

    // Fungsi untuk mengecek apakah data pelanggan ada di server
    private fun checkCustomerData(callback: (Boolean) -> Unit) {
        val url = ApiConfig.GETPELANGGAN + "$userId"
        val request = StringRequest(Request.Method.GET, url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val pelanggan = jsonResponse.optJSONObject("pelanggan")
                    if (pelanggan != null) {
                        callback(true)  // Data pelanggan ditemukan
                    } else {
                        callback(false)  // Data pelanggan tidak ditemukan
                    }
                } catch (e: Exception) {
                    callback(false)  // Error dalam pengambilan data
                }
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                callback(false)  // Error dalam pengambilan data
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }
}
