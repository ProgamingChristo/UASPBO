package com.example.inventoryapp.produk

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object SharedPreferencesHelper {

    private const val PREF_NAME = "cart_prefs"
    private const val CART_KEY = "cart_list"

    // Simpan cartList ke SharedPreferences
    fun saveCartList(context: Context, cartList: MutableList<Produk>) {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(cartList)
        editor.putString(CART_KEY, json)
        editor.apply()
    }

    // Ambil cartList dari SharedPreferences
    fun getCartList(context: Context): MutableList<Produk> {
        val sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString(CART_KEY, null)
        val type = object : TypeToken<MutableList<Produk>>() {}.type
        return if (json != null) {
            gson.fromJson(json, type)
        } else {
            mutableListOf()
        }
    }
}
