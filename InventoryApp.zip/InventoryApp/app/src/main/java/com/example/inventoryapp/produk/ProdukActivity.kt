package com.example.inventoryapp.produk

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.ApiConfig
import com.example.inventoryapp.R
import com.example.inventoryapp.cart.CartActivity
import com.example.inventoryapp.produk.Produk
import com.example.inventoryapp.produk.ProdukAdapter
import com.example.inventoryapp.produk.SharedPreferencesHelper
import com.example.inventoryapp.profile.ProfileActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.Gson
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class ProdukActivity : AppCompatActivity() {

    // Format Rupiah
    private fun formatRupiah(amount: Double): String {
        val localeID = Locale("in", "ID")
        val format = NumberFormat.getCurrencyInstance(localeID)
        return format.format(amount)
    }

    private lateinit var recyclerView: RecyclerView
    private lateinit var produkList: MutableList<Produk>
    private lateinit var adapter: ProdukAdapter
    private val cartList = mutableListOf<Produk>()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.produk)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 2)
        produkList = mutableListOf()
        adapter = ProdukAdapter(produkList) { produk ->

            // Menampilkan SweetAlertDialog untuk memilih jumlah produk
            val inputQuantity = EditText(this)
            inputQuantity.inputType = InputType.TYPE_CLASS_NUMBER
            inputQuantity.hint = "Jumlah produk" // Menambahkan hint

            SweetAlertDialog(this, SweetAlertDialog.NORMAL_TYPE)
                .setTitleText("Tambah ke Keranjang")
                .setContentText("Masukkan jumlah produk yang ingin dibeli. Stok tersedia: ${produk.Stok}")
                .setCustomView(inputQuantity) // Menambahkan EditText ke dalam dialog
                .setConfirmText("Tambah")
                .setCancelText("Batal")
                .setConfirmClickListener { dialog ->
                    val quantity = inputQuantity.text.toString().toIntOrNull()
                    if (quantity != null && quantity > 0 && quantity <= produk.Stok) {
                        // Menambahkan produk ke cart dan menyimpan jumlahnya
                        produk.Quantity = quantity // Tambahkan properti quantity ke produk
                        cartList.add(produk)
                        SharedPreferencesHelper.saveCartList(this, cartList) // Simpan ke SharedPreferences
                        dialog.dismissWithAnimation()
                    } else if (quantity != null && quantity > produk.Stok) {
                        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                            .setTitleText("Jumlah melebihi stok")
                            .setContentText("Jumlah produk yang dimasukkan melebihi stok yang tersedia.")
                            .show()
                    } else {
                        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                            .setTitleText("Jumlah tidak valid")
                            .setContentText("Masukkan jumlah produk yang valid.")
                            .show()
                    }
                }
                .setCancelClickListener { dialog ->
                    dialog.dismissWithAnimation()
                }
                .show()
        }

        recyclerView.adapter = adapter

        fetchProdukData()

        // BottomNavigationView
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomnav)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Tampilkan halaman Home
                    startActivity(Intent(this, ProdukActivity::class.java))
                    true
                }
                R.id.navigation_cart -> {
                    // Tampilkan halaman Cart
                    startActivity(Intent(this, CartActivity::class.java))
                    true
                }
                R.id.navigation_profile -> {
                    // Tampilkan halaman Cart
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // Cek status login
        checkLoginStatus()
    }

    private fun checkLoginStatus() {
        val url = ApiConfig.SESSION_URL
        val request = StringRequest(Request.Method.GET, url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val user = jsonResponse.getJSONObject("user")
                    val userId = user.getInt("userId")
                    // Simpan userId untuk digunakan nanti
                    Log.d("ProdukActivity", "User ID: $userId")

                    // Filter cart berdasarkan userId
                    filterCartByUserId(userId)
                } catch (e: Exception) {
                    Log.e("Login Error", "Error parsing session data: ${e.message}")
                }
            },
            { error ->
                Log.e("API Error", "Error fetching session: ${error.message}")
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    private fun filterCartByUserId(userId: Int) {
        val cartList = SharedPreferencesHelper.getCartList(this)
        // Filter cart berdasarkan userId, jika perlu
        val userCart = cartList.filter { it.ProdukID == userId } // Sesuaikan dengan logika yang diinginkan
        Log.d("Filtered Cart", userCart.toString())
    }

    private fun fetchProdukData() {
        val url = ApiConfig.PRODUK_URL
        val request = StringRequest(
            Request.Method.GET, url,
            { response ->
                try {
                    val gson = Gson()
                    val produkArray = gson.fromJson(response, Array<Produk>::class.java)
                    produkList.addAll(produkArray)

                    // Format harga dalam Rupiah
                    for (produk in produkList) {
                        produk.HargaFormatted = formatRupiah(produk.Harga)
                    }

                    adapter.notifyDataSetChanged()
                } catch (e: Exception) {
                    Log.e("Parsing Error", "Error parsing JSON: ${e.message}")
                }
            },
            { error ->
                Log.e("API Error", "Error fetching data: ${error.message}")
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }
}
