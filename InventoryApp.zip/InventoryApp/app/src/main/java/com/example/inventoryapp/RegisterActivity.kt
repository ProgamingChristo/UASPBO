package com.example.inventoryapp
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var registerButton: Button
    private lateinit var loginText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        // Find views by ID
        usernameEditText = findViewById(R.id.username)
        emailEditText = findViewById(R.id.email)
        passwordEditText = findViewById(R.id.password)
        registerButton = findViewById(R.id.registerButton)
        loginText = findViewById(R.id.loginText)

        // Set up register button click listener
        registerButton.setOnClickListener {
            registerUser()
        }

        // Set up login text click listener to navigate to login
        loginText.setOnClickListener {
            navigateToLogin()
        }
    }

    private fun registerUser() {
        val username = usernameEditText.text.toString()
        val email = emailEditText.text.toString()
        val password = passwordEditText.text.toString()

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Create the request body as JSON
        val requestBody = JSONObject()
        requestBody.put("username", username)
        requestBody.put("email", email)
        requestBody.put("password", password)

        // Create the request to the API
        val url = ApiConfig.REGISTER_URL
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.POST, url, requestBody,
            Response.Listener { response ->
                // Handle success
                Log.d("Register", "Response: $response")
                Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show()
                navigateToLogin()
            },
            Response.ErrorListener { error ->
                // Handle error
                Log.e("Register", "Error: ${error.message}")
                Toast.makeText(this, "Registration Failed. Try Again.", Toast.LENGTH_SHORT).show()
            }
        )

        // Add the request to the Volley request queue
        val queue = Volley.newRequestQueue(this)
        queue.add(jsonObjectRequest)
    }

    private fun navigateToLogin() {
        // Navigate to LoginActivity after successful registration
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
