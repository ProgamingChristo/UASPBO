package com.example.inventoryapp.respons

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.inventoryapp.R
import com.example.inventoryapp.produk.ProdukActivity

class SuccessActivity : AppCompatActivity() {

    private lateinit var handler: Handler

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.success)

        // Handler untuk menunda perpindahan ke ProdukActivity
        handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            navigateToProdukActivity()
        }, 10000) // 10 detik
    }

    // Fungsi untuk navigasi ke ProdukActivity
    private fun navigateToProdukActivity() {
        val intent = Intent(this, ProdukActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish() // Tutup activity saat ini
    }

    // Override tombol back untuk navigasi ke ProdukActivity
    override fun onBackPressed() {
        super.onBackPressed()
        handler.removeCallbacksAndMessages(null) // Hentikan handler jika tombol back ditekan
        navigateToProdukActivity()
    }
}
