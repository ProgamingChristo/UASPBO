package com.example.inventoryapp.produk

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.R
import com.squareup.picasso.Picasso

class ProdukAdapter(
    private val produkList: List<Produk>,
    private val onItemClick: (Produk) -> Unit
) : RecyclerView.Adapter<ProdukAdapter.ProdukViewHolder>() {

    class ProdukViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val title: TextView = itemView.findViewById(R.id.title)
        val harga: TextView = itemView.findViewById(R.id.harga)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProdukViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.produk_item, parent, false)
        return ProdukViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProdukViewHolder, position: Int) {
        val produk = produkList[position]
        holder.title.text = produk.NamaProduk
        holder.harga.text = produk.HargaFormatted
        Picasso.get().load(produk.img_url).into(holder.imageView)

        // Tambahkan listener klik
        holder.itemView.setOnClickListener {
            onItemClick(produk)
        }
    }

    override fun getItemCount() = produkList.size
}
