package com.example.inventoryapp.transaksi

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.inventoryapp.R
import com.example.inventoryapp.produk.Produk
import com.example.inventoryapp.produk.SharedPreferencesHelper

class TransaksiAdapter(context: Context, private val cartList: MutableList<Produk>) :
    ArrayAdapter<Produk>(context, R.layout.transaction_item, cartList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.transaction_item, parent, false)
        val produk = cartList[position]

        val title = view.findViewById<TextView>(R.id.title)
        val harga = view.findViewById<TextView>(R.id.harga)
        val quantity = view.findViewById<TextView>(R.id.quantity) // Menampilkan jumlah produk

        title.text = produk.NamaProduk
        harga.text = produk.HargaFormatted  // Menampilkan harga yang sudah diformat
        quantity.text = "Jumlah: ${produk.Quantity}"  // Menampilkan jumlah produk yang ada di keranjang

        return view
    }
}

