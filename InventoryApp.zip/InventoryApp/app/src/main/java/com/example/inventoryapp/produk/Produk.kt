package com.example.inventoryapp.produk

import java.io.Serializable

data class Produk(
    val ProdukID: Int,
    val NamaProduk: String,
    val Harga: Double,
    val Stok: Int,
    val img_url: String,
    var Quantity: Int = 1,
    var HargaFormatted: String = ""
) : Serializable
