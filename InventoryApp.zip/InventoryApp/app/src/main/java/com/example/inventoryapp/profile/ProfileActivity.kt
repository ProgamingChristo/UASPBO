package com.example.inventoryapp.profile

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.ApiConfig
import com.example.inventoryapp.LoginActivity
import com.example.inventoryapp.R
import com.example.inventoryapp.cart.CartActivity
import com.example.inventoryapp.produk.ProdukActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONObject

class ProfileActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences

    private lateinit var etNama: EditText
    private lateinit var etAlamat: EditText
    private lateinit var etNomorTelepon: EditText
    private lateinit var btnSave: Button

    private var userId: Int = 0
    private var pelangganUserId: Int? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)

        etNama = findViewById(R.id.etNama)
        etAlamat = findViewById(R.id.etAlamat)
        etNomorTelepon = findViewById(R.id.etNomorTelepon)
        btnSave = findViewById(R.id.btnSave)

        // Ambil user_id dari SharedPreferences
        userId = getUserIdFromPreferences()

        if (userId != 0) {
            fetchPelangganData()
        }

        btnSave.setOnClickListener {
            val nama = etNama.text.toString()
            val alamat = etAlamat.text.toString()
            val nomorTelepon = etNomorTelepon.text.toString()

            if (nama.isNotEmpty() && alamat.isNotEmpty() && nomorTelepon.isNotEmpty()) {
                if (pelangganUserId == null) {
                    // Jika pelanggan belum ada, buat baru
                    createPelanggan(nama, alamat, nomorTelepon)
                } else {
                    // Jika pelanggan sudah ada, update data pelanggan
                    updatePelanggan(nama, alamat, nomorTelepon)
                }
            } else {
                Toast.makeText(this, "Semua field harus diisi", Toast.LENGTH_SHORT).show()
            }
        }
        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        // Set up logout button
        val logoutButton: Button = findViewById(R.id.logoutButton)
        logoutButton.setOnClickListener {
            logoutUser()
        }

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomnav)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Tampilkan halaman Home
                    startActivity(Intent(this, ProdukActivity::class.java))
                    true
                }
                R.id.navigation_cart -> {
                    // Tampilkan halaman Cart
                    startActivity(Intent(this, CartActivity::class.java))
                    true
                }
                R.id.navigation_profile -> {
                    // Tampilkan halaman Cart
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }

    }

    private fun fetchPelangganData() {
        val url = ApiConfig.GETPELANGGAN + "$userId"
        Log.d("API Request", "Fetching pelanggan data from: $url")  // Log URL for fetching pelanggan
        val request = StringRequest(Request.Method.GET, url,
            { response ->
                Log.d("API Response", "Pelanggan data response: $response")  // Log the pelanggan response
                try {
                    val jsonResponse = JSONObject(response)
                    val pelanggan = jsonResponse.getJSONObject("pelanggan")
                    pelangganUserId = jsonResponse.getInt("pelangganUserID")

                    // Set data ke form
                    etNama.setText(pelanggan.getString("NamaPelanggan"))
                    etAlamat.setText(pelanggan.getString("Alamat"))
                    etNomorTelepon.setText(pelanggan.getString("NomorTelepon"))

                    // Simpan PelangganID ke SharedPreferences
                    val pelangganId = pelanggan.getInt("PelangganID")
                    savePelangganIdToPreferences(pelangganId)

                } catch (e: Exception) {
                    Log.e("ProfileActivity", "Error fetching pelanggan data: ${e.message}")
                }
            },
            { error ->
                Log.e("API Error", "Error fetching pelanggan data: ${error.message}")
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    private fun createPelanggan(nama: String, alamat: String, nomorTelepon: String) {
        val url = ApiConfig.POSTPELANGGAN
        val jsonParams = JSONObject().apply {
            put("namaPelanggan", nama)
            put("alamat", alamat)
            put("nomorTelepon", nomorTelepon)
            put("user_id", userId)
        }

        Log.d("CreatePelanggan", "Sending JSON: $jsonParams")  // Log JSON sent in the request

        val request = object : StringRequest(Request.Method.POST, url,
            { response ->
                Log.d("API Response", "Pelanggan created response: $response")
                try {
                    val jsonResponse = JSONObject(response)
                    val pelangganId = jsonResponse.getJSONObject("pelanggan").getInt("PelangganID")
                    Log.d("CreatePelanggan", "PelangganID received: $pelangganId")  // Log PelangganID

                    // Simpan PelangganID ke SharedPreferences
                    savePelangganIdToPreferences(pelangganId)

                    Toast.makeText(this, "Pelanggan berhasil dibuat", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Log.e("CreatePelanggan", "Error parsing PelangganID: ${e.message}")
                }
            },
            { error ->
                Log.e("API Error", "Error creating pelanggan: ${error.message}")
            }) {

            // Send raw JSON in the body of the request
            override fun getBody(): ByteArray {
                return jsonParams.toString().toByteArray(Charsets.UTF_8)
            }

            // Set Content-Type to indicate it's JSON
            override fun getHeaders(): MutableMap<String, String> {
                val headers = mutableMapOf<String, String>()
                headers["Content-Type"] = "application/json"
                return headers
            }

        }

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    private fun updatePelanggan(nama: String, alamat: String, nomorTelepon: String) {
        val url = ApiConfig.UPDATEPELANGGAN + "$pelangganUserId"
        val jsonParams = JSONObject().apply {
            put("namaPelanggan", nama)
            put("alamat", alamat)
            put("nomorTelepon", nomorTelepon)
        }

        Log.d("UpdatePelanggan", "Sending JSON: $jsonParams")  // Log JSON sent for update

        val request = object : StringRequest(Request.Method.PUT, url,
            { response ->
                Log.d("API Response", "Pelanggan updated response: $response")
                try {
                    val jsonResponse = JSONObject(response)
                    val pelangganId = jsonResponse.getJSONObject("pelanggan").getInt("PelangganID")
                    Log.d("UpdatePelanggan", "PelangganID received after update: $pelangganId")

                    // Simpan PelangganID ke SharedPreferences
                    savePelangganIdToPreferences(pelangganId)

                    Toast.makeText(this, "Pelanggan berhasil diperbarui", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Log.e("UpdatePelanggan", "Error parsing PelangganID: ${e.message}")
                }
            },
            { error ->
                Log.e("API Error", "Error updating pelanggan: ${error.message}")
            }) {

            // Override getBody to send the raw JSON in the request body
            override fun getBody(): ByteArray {
                return jsonParams.toString().toByteArray(Charsets.UTF_8)
            }

            // Set the Content-Type header to indicate the request is sending JSON
            override fun getHeaders(): MutableMap<String, String> {
                val headers = mutableMapOf<String, String>()
                headers["Content-Type"] = "application/json"
                return headers
            }
        }

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    // Function to get user_id from SharedPreferences
    private fun getUserIdFromPreferences(): Int {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        return sharedPreferences.getInt("user_id", 0) // Return 0 if user_id is not found
    }

    // Function to save PelangganID to SharedPreferences
    private fun savePelangganIdToPreferences(pelangganId: Int) {
        val sharedPreferences: SharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putInt("pelanggan_id_$userId", pelangganId) // Save the PelangganID with key based on user_id
        editor.apply()

        Log.d("SavePelangganId", "PelangganID saved to preferences for user_id $userId: $pelangganId")  // Log PelangganID saved
    }

    private fun logoutUser() {
        val editor = sharedPreferences.edit()
        editor.clear() // Remove all data from SharedPreferences
        editor.apply()

        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
