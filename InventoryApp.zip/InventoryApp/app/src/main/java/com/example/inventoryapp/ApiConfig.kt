package com.example.inventoryapp

object ApiConfig {
    // URL dasar untuk server
    const val BASE_URL = "http://192.168.1.203:3030"

    const val REGISTER_URL = "$BASE_URL/api/auth/register"

    const val LOGIN_URL = "$BASE_URL/api/auth/login"

    const val PRODUK_URL = "$BASE_URL/api/produk"

    const val SESSION_URL = "$BASE_URL/api/auth/sess"

    // pelangganuser
    const val GETPELANGGAN = "$BASE_URL/api/pelanggan-user/user/"
    const val POSTPELANGGAN = "$BASE_URL/api/pelanggan-user"
    const val UPDATEPELANGGAN = "$BASE_URL/api/pelanggan-user/"

    // pembelian barang (Request)
    const val POSTPEMBELIAN = "$BASE_URL/api/pembelian"
    const val PROSESPEMBELIAN = "$BASE_URL/api/pembelian/"

}
