package com.example.inventoryapp

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.produk.ProdukActivity
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var registerTextView: TextView
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        // Check if user is already logged in
        if (sharedPreferences.contains("user_id")) {
            navigateToProdukActivity()
        }

        // Initialize UI elements
        emailEditText = findViewById(R.id.Email)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.loginButton)
        registerTextView = findViewById(R.id.registerText)

        // Handle login button click
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Check if inputs are valid
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show()
            } else {
                loginUser(email, password)
            }
        }

        // Handle register redirection
        registerTextView.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    // Function to handle login request
    private fun loginUser(email: String, password: String) {
        val url = ApiConfig.LOGIN_URL

        // Prepare the JSON body for the login request
        val loginData = JSONObject()
        loginData.put("email", email)
        loginData.put("password", password)

        // Create a request queue
        val requestQueue = Volley.newRequestQueue(this)

        // Create a JSON object request to send the login data
        val loginRequest = JsonObjectRequest(
            Request.Method.POST,
            url,
            loginData,
            Response.Listener { response ->
                // Handle the response (successful login)
                try {
                    val userId = response.getInt("user_id") // Ambil user_id dari response login
                    saveUserIdToPreferences(userId) // Simpan user_id ke SharedPreferences
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                    navigateToProdukActivity()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error parsing response", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Handle the error (failed login)
                Toast.makeText(this, "Login failed: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        )

        // Add the request to the queue
        requestQueue.add(loginRequest)
    }

    // Function to save user_id to SharedPreferences
    private fun saveUserIdToPreferences(userId: Int) {
        val editor = sharedPreferences.edit()
        editor.putInt("user_id", userId) // Save the user_id
        editor.apply()
    }

    // Function to navigate to ProdukActivity
    private fun navigateToProdukActivity() {
        val intent = Intent(this, ProdukActivity::class.java)
        startActivity(intent)
        finish() // Close LoginActivity
    }
}
