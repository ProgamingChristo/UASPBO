package com.example.inventoryapp.respons

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.inventoryapp.ApiConfig
import com.example.inventoryapp.R
import org.json.JSONObject

class ProsesActivity : AppCompatActivity() {

    private lateinit var statusTextView: TextView
    private var pembelianID: Int = 0
    private val handler = Handler(Looper.getMainLooper())
    private val statusCheckRunnable = object : Runnable {
        override fun run() {
            checkPembelianStatus()
            handler.postDelayed(this, 5000)  // Cek setiap 5 detik
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.proses)

        statusTextView = findViewById(R.id.statusTextView)

        // Ambil pembelianID dari SharedPreferences
        val sharedPreferences = getSharedPreferences("TransactionPrefs", MODE_PRIVATE)
        pembelianID = sharedPreferences.getInt("pembelianID", 0)

        // Mulai pengecekan status
        handler.post(statusCheckRunnable)
    }

    private fun checkPembelianStatus() {
        val url = ApiConfig.PROSESPEMBELIAN + "$pembelianID"
        val request = StringRequest(
            Request.Method.GET, url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val status = jsonResponse.getString("status")

                    // Periksa status, jika bukan "pending", arahkan ke halaman success
                    if (status != "pending") {
                        handler.removeCallbacks(statusCheckRunnable)  // Berhenti cek status
                        navigateToSuccess()  // Arahkan ke halaman success
                    }

                } catch (e: Exception) {
                    Toast.makeText(this, "Error checking status", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            })

        val requestQueue = Volley.newRequestQueue(this)
        requestQueue.add(request)
    }

    private fun navigateToSuccess() {
        val intent = Intent(this, SuccessActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(statusCheckRunnable)  // Pastikan pengecekan status dihentikan jika activity dihancurkan
    }
}
