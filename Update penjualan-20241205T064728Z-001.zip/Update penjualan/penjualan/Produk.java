package com.example.inventorydesktop.penjualan;

public class Produk {
    private int ProdukID;
    private String NamaProduk;

    // Getters and setters
    public String getNamaProduk() { return NamaProduk; }
}
