package com.example.inventorydesktop.penjualan;

public class Pelanggan {
    private int PelangganID;
    private String NamaPelanggan;
    private String Alamat;
    private String NomorTelepon;

    // Getters and setters
    public String getNamaPelanggan() { return NamaPelanggan; }
    public String getAlamat() { return Alamat; }
    public String getNomorTelepon() { return NomorTelepon; }
}
